import React, { Component } from 'react';
import '../App.css';

class CreateNewTimer extends Component {
    render() {
        return (
            <div className="CreateNewTimer">
                <p className='plus'>
                    +
                </p>
            </div>
        );
    }
}

export default CreateNewTimer;
